package com.ecojust.puretv;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ApplicationInfo;
import android.graphics.Color;
import android.graphics.Rect;
import android.graphics.drawable.ColorDrawable;
import android.media.tv.TvContract;
import android.media.tv.TvInputInfo;
import android.media.tv.TvInputManager;
import android.net.Uri;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.WindowManager;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Minimal home screen with four shortcuts and a separate application list.
 */
public class MainActivity extends Activity implements AppAdapter.TileListener {

    /** The four approved home shortcuts remain one row. */
    static final int COLUMNS = 4;
    private int layoutColumns = COLUMNS;
    private String layoutSignature = "";
    /** config.xml defaults with an optional config.json theme overlay on top. */
    private Config cfg;
    /** The wallpaper file on the TV; null until something asks for it. */
    private Wallpaper wall;
    /** The "Desktop settings" panel, so Back can close it. */
    private PopupWindow wallpaperPanel;
    /** The picture behind the desk, when there is one; removed and re-added as the wallpaper changes. */
    private ImageView wallpaperView;
    private static final int REQ_PICK_WALLPAPER = 41;
    /** Weak boxes cannot keep up with the tweens; this turns the desk's motion down to a minimum. */
    private boolean reducedMotion;
    private static final String PREFS_LAYOUT = "layout";
    private static final String KEY_REDUCED_MOTION = "reduced_motion";
    /**
     * Launch the desk straight into its own settings panel. The quick settings overlay
     * ({@link QuickSettingsActivity}) sends this, so the remote's Settings button can reach the wallpaper
     * and icon-per-row settings without a second settings screen.
     */
    public static final String ACTION_DESKTOP_SETTINGS = "com.ecojust.puretv.action.DESKTOP_SETTINGS";
    /** Same route for the Favourites (dock) panel, so the quick settings overlay can offer it too. */
    public static final String ACTION_DOCK_PICKER = "com.ecojust.puretv.action.DOCK_PICKER";
    private static final long MINUTE_MS = 60_000L;
    private String liveTvPkg;

    private AppAdapter adapter;
    private RecyclerView grid;
    private FrameLayout root;
    private TextView btnWifi;
    // Static so they survive the activity being destroyed while another app is open (low-memory TVs,
    // or Developer options → "Don't keep activities"); they only reset when the process dies.
    private static int lastFocused = 0;
    /** App of the last focused tile, so focus follows it when the app list changes. */
    private static String lastFocusedKey;
    private float density;

    private final Handler handler = new Handler(Looper.getMainLooper());
    /** Refreshes the network pill when the connection changes: at boot Wi-Fi often connects after Home is shown. */
    private final ConnectivityManager.NetworkCallback networkCallback = new ConnectivityManager.NetworkCallback() {
        @Override
        public void onAvailable(@NonNull Network network) {
            handler.post(MainActivity.this::updateWifiLabel);
        }

        @Override
        public void onLost(@NonNull Network network) {
            handler.post(MainActivity.this::updateWifiLabel);
        }
    };
    private final Runnable minuteTick = new Runnable() {
        @Override
        public void run() {
            updateWifiLabel();
            handler.postDelayed(this, MINUTE_MS);
        }
    };

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        if (intent == null) return;
        String action = intent.getAction();
        if (ACTION_DESKTOP_SETTINGS.equals(action) || ACTION_DOCK_PICKER.equals(action)) {
            openPanelFromQuickSettings(action);
            return;
        }
        if (!intent.hasCategory(Intent.CATEGORY_HOME)) return;
        scrollToTop();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        live = new WeakReference<>(this);
        density = getResources().getDisplayMetrics().density;
        // config.xml defaults, then a config.json overlay pushed by tools/theme.sh if one is there.
        cfg = Config.load(this);
        liveTvPkg = cfg.liveTvPackage.trim();

        root = findViewById(R.id.root);
        // A theme may paint the whole background: a colour, a wallpaper, or nothing beyond both.
        root.setBackgroundColor(cfg.backgroundColor);
        weather = new Weather(this);
        setupWeather();
        if (cfg.wallpaper != null) showWallpaper(cfg.wallpaper);
        btnWifi = findViewById(R.id.btnWifi);

        grid = findViewById(R.id.grid);
        grid.setLayoutManager(new GridLayoutManager(this, layoutColumns));
        grid.setHasFixedSize(false);
        grid.setItemAnimator(null);
        reducedMotion = getSharedPreferences(PREFS_LAYOUT, MODE_PRIVATE)
                .getBoolean(KEY_REDUCED_MOTION, false);
        AppAdapter.setReducedMotion(reducedMotion);
        adapter = new AppAdapter(this, this, COLUMNS, AppAdapter.homeEntries());
        grid.setAdapter(adapter);

        View btnInputs = findViewById(R.id.btnInputs);
        View btnSettings = findViewById(R.id.btnSettings);
        findViewById(R.id.btnDock).setOnClickListener(v -> showDockPicker());
        findViewById(R.id.btnWallpaper).setOnClickListener(v -> showWallpaperPicker());
        findViewById(R.id.allAppsHint).setOnClickListener(v -> openAppList());
        btnInputs.setOnClickListener(v -> showInputs());
        btnWifi.setOnClickListener(v -> open(systemIntent(Settings.ACTION_WIFI_SETTINGS)));
        btnSettings.setOnClickListener(v -> open(systemIntent(Settings.ACTION_SETTINGS)));

        // Keep focus on the top bar at its ends and at the top: Android's focus finder would otherwise
        // jump to a tile far below when there is nothing in that direction.
        View.OnKeyListener pillKeys = (v, keyCode, event) -> {
            if (event.getAction() != KeyEvent.ACTION_DOWN) return false;
            if (keyCode == KeyEvent.KEYCODE_DPAD_UP) return true;
            if (keyCode == KeyEvent.KEYCODE_DPAD_DOWN) {
                // Back to the dock tile Up came from, not wherever the focus finder happens to land.
                focusTile(lastFocused % layoutColumns);
                return true;
            }
            if (keyCode == KeyEvent.KEYCODE_DPAD_LEFT && v.getId() == R.id.btnWallpaper) return true;
            return keyCode == KeyEvent.KEYCODE_DPAD_RIGHT && v.getId() == R.id.btnSettings;
        };
        findViewById(R.id.btnDock).setOnKeyListener(pillKeys);
        findViewById(R.id.btnWallpaper).setOnKeyListener(pillKeys);
        btnInputs.setOnKeyListener(pillKeys);
        btnWifi.setOnKeyListener(pillKeys);
        btnSettings.setOnKeyListener(pillKeys);

        ConnectivityManager cm = getSystemService(ConnectivityManager.class);
        if (cm != null) cm.registerDefaultNetworkCallback(networkCallback);

        // If the user left the daily wallpaper on, make sure today's picture is there before they see
        // the desk. Runs in the background and re-applies only when something actually changed.
        wall = new Wallpaper(this);
        if (wall.autoDaily()) {
            new Thread(() -> {
                final boolean done = wall.refreshDailyIfDue();
                if (done) handler.post(this::applyWallpaper);
            }).start();
        }

        // Started by the quick settings overlay when the desk was not running yet (the usual case,
        // since the panel also floats over apps, not just over the desktop).
        openPanelFromQuickSettings(getIntent().getAction());
    }

    /** Opens one of the desk's own panels, whichever route asked for it (quick settings or a cold start). */
    private void openPanelFromQuickSettings(String action) {
        if (ACTION_DESKTOP_SETTINGS.equals(action)) grid.post(this::showWallpaperPicker);
        else if (ACTION_DOCK_PICKER.equals(action)) grid.post(this::showDockPicker);
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Read these before reload(): rebinding can move focus to the first tile and overwrite them.
        final String returnKey = lastFocusedKey;
        final int returnSlot = lastFocused;
        // The adapter was let go of when memory ran short: put it back before loading the tiles again.
        if (grid.getAdapter() == null) grid.setAdapter(adapter);
        if (wallpaperReleased) {
            wallpaperReleased = false;
            applyWallpaper();
        }
        reloadCustomLayout();
        if (weather != null && weather.enabled()) refreshWeather();
        updateWifiLabel();
        handler.postDelayed(minuteTick, MINUTE_MS);
        if (weather != null && weather.enabled() && weather.hasPlace()) {
            handler.postDelayed(weatherTick, Weather.REFRESH_MS);
        }

        // Return to the app we left from, or the same slot if that app is gone. Always refocus: after
        // reload() the view that holds focus may no longer show the app it had.
        grid.post(() -> {
            int pos = adapter.positionOf(returnKey);
            focusTile(pos >= 0 ? pos : returnSlot);
        });
    }

    static void reloadLayoutFromManager() {
        MainActivity activity=live==null?null:live.get();
        if(activity!=null) activity.runOnUiThread(activity::reloadCustomLayout);
    }
    private void reloadCustomLayout() {
        LauncherLayout layout=LauncherLayout.override(this);
        String signature=layout==null?"":layout.json.toString();
        if (!signature.equals(layoutSignature)) {
            layoutSignature=signature;layoutColumns=layout==null?COLUMNS:layout.columns;
            adapter.clear();
            adapter=new AppAdapter(this,this,layoutColumns,layout==null?AppAdapter.homeEntries():layout.entries(this,"home"));
            grid.setLayoutManager(new GridLayoutManager(this,layoutColumns));grid.setAdapter(adapter);
            boolean multipleRows=adapter.getItemCount()>layoutColumns;
            findViewById(R.id.homeSpacer).setVisibility(multipleRows?View.GONE:View.VISIBLE);
            android.widget.LinearLayout.LayoutParams params=(android.widget.LinearLayout.LayoutParams)grid.getLayoutParams();
            params.height=multipleRows?0:android.view.ViewGroup.LayoutParams.WRAP_CONTENT;params.weight=multipleRows?1:0;grid.setLayoutParams(params);
            grid.post(()->focusTile(Math.min(lastFocused,adapter.getItemCount()-1)));
        } else adapter.reload();
    }

    @Override
    protected void onPause() {
        super.onPause();
        handler.removeCallbacks(minuteTick);
        handler.removeCallbacks(weatherTick);   // nothing is fetched while the desk is off screen
    }

    @Override
    protected void onStart() {
        super.onStart();
        started = true;
    }

    @Override
    protected void onStop() {
        // Another app took the screen. A translucent overlay (the panels, the quick settings)
        // only pauses us, so this really does mean the desk was left behind.
        started = false;
        super.onStop();
    }

    /**
     * The system wants memory back. The banners behind the tiles are the largest thing this launcher
     * holds, so when Home is in the background and the box is short on memory, they go: the tiles, the
     * adapter itself and the wallpaper bitmap are let go, and onResume puts them back.
     *
     * <p>Not while the desk is on screen. RUNNING_LOW and CRITICAL also arrive then, because an
     * accessibility service keeps the process in the foreground, and blanking the screen the owner is
     * looking at would be worse than the memory.
     */
    @Override
    public void onTrimMemory(int level) {
        super.onTrimMemory(level);
        boolean due = level >= TRIM_MEMORY_BACKGROUND
                || level == TRIM_MEMORY_RUNNING_LOW || level == TRIM_MEMORY_RUNNING_CRITICAL;
        if (!due || started || adapter == null) return;
        adapter.clear();
        // Detach the adapter as well: with Home stopped no layout pass runs, so the tile views (and the
        // bitmaps they hold) would stay attached until Home comes back.
        grid.setAdapter(null);
        grid.getRecycledViewPool().clear();
        if (wallpaperView != null) {
            removeWallpaper();
            wallpaperReleased = true;
        }
    }

    @Override
    protected void onDestroy() {
        live = null;
        super.onDestroy();
        ConnectivityManager cm = getSystemService(ConnectivityManager.class);
        if (cm != null) cm.unregisterNetworkCallback(networkCallback);
    }

    @Override
    public void onBackPressed() {
        // Home screen: Back goes nowhere.
    }

    /** Whether the Menu button should open quick settings from other apps too (see HomeKeyService). */
    boolean menuKeyEverywhere() {
        return getSharedPreferences(HomeKeyService.PREFS, MODE_PRIVATE)
                .getBoolean(HomeKeyService.KEY_MENU_EVERYWHERE, false);
    }

    /** Whether the tweens are turned down for a box that cannot keep up with them. */
    boolean reducedMotion() {
        return getSharedPreferences(PREFS_LAYOUT, MODE_PRIVATE)
                .getBoolean(KEY_REDUCED_MOTION, false);
    }

    /** True when config.xml names the TV's own source panel. */
    private boolean panelConfigured() {
        String service = cfg.sourcePanelService == null ? "" : cfg.sourcePanelService.trim();
        String action = cfg.sourcePanelAction == null ? "" : cfg.sourcePanelAction.trim();
        return !service.isEmpty() || !action.isEmpty();
    }

    /**
     * Open the TV's own source panel. The panel is sometimes an activity (a dialog on some sets) and
     * sometimes a service, so try it as the activity it resolves to first and fall back to a service.
     */
    private void openSourcePanel() {
        Intent panel = sourcePanelIntent();
        if (panel == null) {
            Toast.makeText(this, R.string.no_inputs, Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            if (panel.getComponent() != null && getPackageManager().resolveService(panel, 0) != null) {
                startService(panel.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
            } else {
                open(panel);
            }
        } catch (Exception e) {
            Toast.makeText(this, R.string.not_available, Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * The TV's own source-selection panel, for sets that do not report their inputs to the launcher.
     *
     * <p>Tried in order: the component named in config.xml (per vendor), then the action named there,
     * then AOSP's own input-source page — the platform has no constant for it, but TV ROMs answer this
     * action string. There is deliberately no "plain system settings" last resort: on a box with no
     * source panel at all (a Google TV stick, say) that just opens the settings the user was already
     *looking at, which reads like a bug. Null means we have nothing better to offer, and the caller
     * says so instead.
     */
    private Intent sourcePanelIntent() {
        String service = cfg.sourcePanelService == null ? "" : cfg.sourcePanelService.trim();
        String action = cfg.sourcePanelAction == null ? "" : cfg.sourcePanelAction.trim();
        if (!service.isEmpty()) {
            Intent byComponent = new Intent().setComponent(ComponentName.unflattenFromString(service));
            if (byComponent.resolveActivity(getPackageManager()) != null) return byComponent;
        }
        if (!action.isEmpty()) {
            Intent byAction = new Intent(action);
            if (byAction.resolveActivity(getPackageManager()) != null) return byAction;
        }
        Intent tvInputs = new Intent("android.settings.INPUT_SOURCE_SETTINGS");
        return tvInputs.resolveActivity(getPackageManager()) != null ? tvInputs : null;
    }

    /**
     * True while another app is in front. Coming back then means the user asked for the desk, and the
     * desk opens at the top — the same thing the Home key does everywhere else. Inside the desk (a panel
     * closing, the volume dialog, the quick settings overlay) onStop does not fire, so nothing moves.
     */
    /** True between onStart and onStop: the desk is (at least partly) on screen. */
    private boolean started;
    /** Set when the wallpaper bitmap was handed back to the system; it comes back on resume. */
    private boolean wallpaperReleased;
    /** The weather line under the clock, and the loop that keeps it current. */
    private Weather weather;
    private View weatherLine;
    private ImageView weatherIcon;
    private TextView weatherText;
    private Weather.Report weatherReport;
    private PopupWindow weatherPanel;
    private final Runnable weatherTick = this::refreshWeather;
    /** One thread for the network: the weather, the city search, the locate. */
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    /** HomeKeyService cannot reach an activity directly; this is the live one, weakly held. */
    private static WeakReference<MainActivity> live;

    /** Called by {@link HomeKeyService} when Home is pressed while the desk is already in front. */
    static void onHomeKeyFromService() {
        MainActivity activity = live == null ? null : live.get();
        if (activity != null) activity.runOnUiThread(activity::scrollToTop);
    }

    /** Back to the first tile, the way the Home button behaves on a phone launcher. */
    private void scrollToTop() {
        if (adapter == null || adapter.getItemCount() == 0) return;
        lastFocused = 0;
        lastFocusedKey = adapter.keyAt(0);
        grid.scrollToPosition(0);
        // Focus after the layout pass that moves the rows. Straight after scrollToPosition the holder
        // found for position 0 is still the old one, and asking a view that is about to be recycled for
        // focus is how the highlight ended up nowhere at all.
        grid.post(() -> {
            RecyclerView.ViewHolder vh = grid.findViewHolderForAdapterPosition(0);
            if (vh == null) {
                focusTile(0);           // not laid out yet: focusTile waits for the scroll to settle
                return;
            }
            View card = vh.itemView.findViewById(R.id.card);
            onTileFocused(0, card);    // already focused: no focus event will fire, so place it by hand
            card.requestFocus();
        });
    }

    /**
     * The remote's Menu (or Settings) button opens the quick settings panel, the way TV boxes with a
     * built-in launcher do it: one press for the handful of places you actually go, including this
     * launcher's own two panels. Dispatched here rather than through a key listener so it works from
     * anywhere on the desk, including when nothing is focused.
     *
     * <p>This used to open the dock editor on its own. The panel carries a Favourites row for it, so
     * nothing is lost, and the Favourites pill on the top bar still opens it in one press. A remote
     * that sends a real KEYCODE_SETTINGS or KEYCODE_HELP gets the same panel, and HomeKeyService
     * opens it from other apps; swallowing it globally would break it inside other apps.
     */
    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        int code = event.getKeyCode();
        // Home while the desk is already in front means "take me back to the top", not "relaunch me".
        // Handling it here rather than in onNewIntent because plenty of paths (a remote that sends a
        // plain KEYCODE_HOME, a shell-injected key) never re-deliver the HOME intent at all.
        if (code == KeyEvent.KEYCODE_HOME) {
            if (event.getAction() == KeyEvent.ACTION_DOWN) scrollToTop();
            return true;
        }
        if (code == KeyEvent.KEYCODE_MENU
                || code == KeyEvent.KEYCODE_SETTINGS
                || code == KeyEvent.KEYCODE_HELP) {
            // Both actions are consumed: an unhandled remote key gets the system's "this app does not
            // support that button" toast on some boxes.
            if (event.getAction() == KeyEvent.ACTION_DOWN) {
                startActivity(new Intent(this, QuickSettingsActivity.class));
            }
            return true;
        }
        if (event.getAction() == KeyEvent.ACTION_DOWN
                && (code == KeyEvent.KEYCODE_APP_SWITCH
                || code == KeyEvent.KEYCODE_GUIDE)) {
            showDockPicker();
            return true;
        }
        return super.dispatchKeyEvent(event);
    }

    /** The favourites navigation returns focus to the four home shortcuts. */
    private void showDockPicker() {
        scrollToTop();
    }

    private void openAppList() {
        startActivity(new Intent(this, AppsActivity.class));
    }

    private void toast(String text) {
        Toast.makeText(this, text, Toast.LENGTH_SHORT).show();
    }

    // ---- wallpaper ------------------------------------------------------------------------------

    /**
     * "Wallpaper" panel: turn the Daily random picture on or off, pick a picture already on the TV, or
     * drop the wallpaper entirely. The panel is a popup because it is a one-off setting, not a place
     * the user browses.
     */
    private void showWallpaperPicker() {
        if (wallpaperPanel != null && wallpaperPanel.isShowing()) {
            wallpaperPanel.dismiss();
            return;
        }
        wall = new Wallpaper(this);

        View panel = getLayoutInflater().inflate(R.layout.popup_wallpaper, root, false);
        ImageView dailyWallpaperTick = panel.findViewById(R.id.dailyWallpaperTick);
        TextView status = panel.findViewById(R.id.dailyWallpaperStatus);
        TextView columnsStatus = panel.findViewById(R.id.columnsStatus);
        View rowDailyWallpaper = panel.findViewById(R.id.rowDailyWallpaper);
        View rowColumns = panel.findViewById(R.id.rowColumns);
        View rowPick = panel.findViewById(R.id.rowPick);
        View rowOff = panel.findViewById(R.id.rowOff);

        dailyWallpaperTick.setVisibility(wall.autoDaily() ? View.VISIBLE : View.INVISIBLE);
        status.setText(wallpaperStatus());
        rowColumns.setVisibility(View.GONE);

        rowDailyWallpaper.setOnClickListener(v -> {
            boolean on = !wall.autoDaily();
            wall.setAutoDaily(on);
            dailyWallpaperTick.setVisibility(on ? View.VISIBLE : View.INVISIBLE);
            if (on) {
                status.setText(getString(R.string.daily_wallpaper_fetching));
                toast(getString(R.string.daily_wallpaper_fetching));
                // Off the main thread: this hits the network and must never stall the home screen.
                new Thread(() -> {
                    boolean done = wall.refreshDailyIfDue();
                    handler.post(() -> {
                        status.setText(wallpaperStatus());
                        if (done) {
                            toast(getString(R.string.daily_wallpaper_updated));
                            applyWallpaper();
                        } else {
                            toast(getString(R.string.daily_wallpaper_failed));
                        }
                    });
                }).start();
            } else {
                // Only stop the daily change; whatever is on screen now stays.
                status.setText(wallpaperStatus());
                toast(getString(R.string.daily_wallpaper_stopped));
            }
        });


        final TextView menuKeyStatus = panel.findViewById(R.id.menuKeyStatus);
        final View rowMenuKey = panel.findViewById(R.id.rowMenuKey);
        menuKeyStatus.setText(menuKeyEverywhere()
                ? getString(R.string.menu_key_scope_on) : getString(R.string.menu_key_scope_off));
        rowMenuKey.setOnClickListener(v -> {
            boolean on = !menuKeyEverywhere();
            getSharedPreferences(HomeKeyService.PREFS, MODE_PRIVATE)
                    .edit().putBoolean(HomeKeyService.KEY_MENU_EVERYWHERE, on).apply();
            menuKeyStatus.setText(on
                    ? getString(R.string.menu_key_scope_on) : getString(R.string.menu_key_scope_off));
            toast(getString(on ? R.string.menu_key_on : R.string.menu_key_off));
        });

        final TextView motionStatus = panel.findViewById(R.id.motionStatus);
        final View rowMotion = panel.findViewById(R.id.rowMotion);
        motionStatus.setText(reducedMotion()
                ? getString(R.string.reduced_motion_on) : getString(R.string.reduced_motion_off));
        final TextView weatherStatus = panel.findViewById(R.id.weatherStatus);
        final View rowWeather = panel.findViewById(R.id.rowWeather);
        weatherStatus.setText(weather.enabled() && weather.hasPlace()
                ? weather.placeName() : getString(R.string.weather_state_off));
        rowWeather.setOnClickListener(v -> toggleWeather(weatherStatus));

        rowMotion.setOnClickListener(v -> {
            boolean on = !reducedMotion();
            getSharedPreferences(PREFS_LAYOUT, MODE_PRIVATE).edit().putBoolean(KEY_REDUCED_MOTION, on).apply();
            motionStatus.setText(on ? getString(R.string.reduced_motion_on) : getString(R.string.reduced_motion_off));
            toast(getString(on ? R.string.reduced_motion_turned_on : R.string.reduced_motion_turned_off));
            // The tile size maths reads the zoom factor, so the desk has to be rebuilt for it to apply.
            recreate();
        });

        rowPick.setOnClickListener(v -> {
            Intent pick = new Intent(Intent.ACTION_OPEN_DOCUMENT)
                    .addCategory(Intent.CATEGORY_OPENABLE)
                    .setType("image/*");
            try {
                wallpaperPanel.dismiss();
                startActivityForResult(pick, REQ_PICK_WALLPAPER);
            } catch (ActivityNotFoundException e) {
                toast(getString(R.string.not_available));
            }
        });

        rowOff.setOnClickListener(v -> {
            boolean removed = wall.clear();
            dailyWallpaperTick.setVisibility(View.INVISIBLE);
            wall.setAutoDaily(false);
            status.setText(wallpaperStatus());
            // Drop the picture from the desk straight away; a wallpaper that stays on screen after
            // the user asked to remove it looks like the button did nothing.
            removeWallpaper();
            toast(getString(removed ? R.string.wallpaper_removed : R.string.wallpaper_none_toast));
        });

        View anchor = findViewById(R.id.btnWallpaper);
        // Sized from its content and hung under the button with the left edges aligned, exactly like
        // the Inputs menu. No row scaling: a scaled row is what used to need clipping turned off, and
        // the focus pill alone is enough to see where you are.
        wallpaperPanel = settingsPanel(panel, anchor, 300);
        dropIn(wallpaperPanel, panel, anchor, Gravity.START);
    }

    /** One line telling the user what the wallpaper is right now. */
    private String wallpaperStatus() {
        if (wall == null) wall = new Wallpaper(this);
        if (wall.hasWallpaper()) {
            long kb = Math.max(1, wall.sizeBytes() / 1024);
            return getString(R.string.wallpaper_on, kb);
        }
        return getString(R.string.wallpaper_none);
    }

    /** The user picked a file in the system picker. Copy it in as the one and only wallpaper. */
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FileBrowser.REQUEST_OPEN) {
            if (resultCode == RESULT_OK && data != null) FileBrowser.openSelected(this, data.getData());
            return;
        }
        if (requestCode != REQ_PICK_WALLPAPER || resultCode != RESULT_OK || data == null) return;
        Uri uri = data.getData();
        if (uri == null) return;
        if (wall == null) wall = new Wallpaper(this);
        if (wall.importFrom(uri)) {
            toast(getString(R.string.wallpaper_set));
            applyWallpaper();
        } else {
            toast(getString(R.string.wallpaper_bad));
        }
    }

    /**
     * A theme's full-screen picture behind everything. Decoded once, downsampled to the screen so a 4K
     * JPEG costs a 1080p bitmap at most (about 8 MB), which is the price of a wallpaper on a 1 GB TV.
     * Kept as a field so a wallpaper can be added or dropped in place, without rebuilding the activity.
     */
    private void showWallpaper(java.io.File file) {
        removeWallpaper();
        try {
            android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
            android.graphics.BitmapFactory.Options opts = new android.graphics.BitmapFactory.Options();
            opts.inJustDecodeBounds = true;
            android.graphics.BitmapFactory.decodeFile(file.getPath(), opts);
            int w = opts.outWidth, h = opts.outHeight;
            if (w <= 0 || h <= 0) return;
            int sample = WallpaperSize.sampleSize(w, h, dm.widthPixels, dm.heightPixels);
            // The limit applies to what is decoded, so a 12 MP photo still works once it is sampled down.
            if (!WallpaperSize.accepted(w / sample, h / sample)) return;
            opts.inJustDecodeBounds = false;
            opts.inSampleSize = sample;
            int[] scale = WallpaperSize.coverScale(w / sample, h / sample, dm.widthPixels, dm.heightPixels);
            if (scale != null) {
                opts.inScaled = true;
                opts.inDensity = scale[0];
                opts.inTargetDensity = scale[1];
            }
            opts.inPreferredConfig = android.graphics.Bitmap.Config.RGB_565;   // no alpha needed, half the memory
            android.graphics.Bitmap bmp = android.graphics.BitmapFactory.decodeFile(file.getPath(), opts);
            if (bmp == null) return;
            ImageView view = new ImageView(this);
            view.setScaleType(ImageView.ScaleType.CENTER_CROP);
            view.setImageBitmap(bmp);
            view.setColorFilter(0x99000000, android.graphics.PorterDuff.Mode.SRC_ATOP);
            root.addView(view, 0, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            wallpaperView = view;
        } catch (Exception | OutOfMemoryError e) {
            // A bad or huge picture must never take the home screen down; the plain colour stays.
        }
    }

    private void removeWallpaper() {
        if (wallpaperView != null) {
            root.removeView(wallpaperView);
            wallpaperView = null;
        }
    }

    /** Re-apply whatever wallpaper is on disk now, adding or dropping it as needed. */
    private void applyWallpaper() {
        if (wall == null) wall = new Wallpaper(this);
        java.io.File f = wall.file();
        if (f != null && f.isFile() && f.length() > 0) showWallpaper(f);
        else removeWallpaper();
    }

    @Override
    public void onTileFocused(int position, View card) {
        lastFocused = position;
        lastFocusedKey = adapter.keyAt(position);
    }

    // ---- weather ----------------------------------------------------------------------------------

    /** Wire the line under the clock; it stays hidden until the user turns the weather on. */
    private void setupWeather() {
        weatherLine = findViewById(R.id.weatherLine);
        weatherIcon = findViewById(R.id.weatherIcon);
        weatherText = findViewById(R.id.weatherText);
        weatherLine.setOnClickListener(v -> showWeatherPanel());
        if (weather.enabled() && weather.hasPlace()) weatherLine.setVisibility(View.VISIBLE);
    }

    /** Toggle from the desktop settings panel, and keep the row's subtitle honest. */
    private void toggleWeather(TextView status) {
        if (weather.enabled()) {
            weather.enabled(false);
            weatherLine.setVisibility(View.GONE);
            handler.removeCallbacks(weatherTick);
            if (weatherPanel != null) weatherPanel.dismiss();
            status.setText(getString(R.string.weather_state_off));
            toast(getString(R.string.weather_turned_off));
            return;
        }
        weather.enabled(true);
        if (weather.hasPlace()) {
            weatherLine.setVisibility(View.VISIBLE);
            refreshWeather();
            handler.postDelayed(weatherTick, Weather.REFRESH_MS);
            status.setText(weather.placeName());
            toast(getString(R.string.weather_turned_on));
        } else {
            // No place yet: start from the TV's own language, the user can change it in one press.
            Weather.Place guess = guessCity();
            weather.place(guess.name, guess.lat, guess.lon);
            weatherLine.setVisibility(View.VISIBLE);
            status.setText(weather.placeName());
            toast(getString(R.string.weather_turned_on));
            refreshWeather();
            handler.postDelayed(weatherTick, Weather.REFRESH_MS);
        }
    }

    /**
     * A starting city from the TV's language: nothing is sent, nothing is guessed from the network.
     * Chinese, Japanese and Korean get their own capital; everything else starts in London.
     */
    private Weather.Place guessCity() {
        String l = Locale.getDefault().getLanguage();
        if (l == null) l = "en";
        switch (l) {
            case "zh": return new Weather.Place("北京", "中国", 39.9075, 116.39723);
            case "ja": return new Weather.Place("東京", "日本", 35.6895, 139.6917);
            case "ko": return new Weather.Place("서울", "대한민국", 37.5665, 126.9780);
            default:   return new Weather.Place("London", "United Kingdom", 51.5072, -0.1276);
        }
    }

    private void refreshWeather() {
        if (weather == null || !weather.enabled() || !weather.hasPlace()) return;
        executor.execute(() -> {
            Weather.Report r;
            try {
                r = weather.fetch();
            } catch (Exception e) {
                r = null;
            }
            Weather.Report report = r;
            handler.post(() -> {
                if (report == null) return;   // offline: the line keeps the last reading it had
                weatherReport = report;
                showWeatherLine();
                if (weatherPanel != null && weatherPanel.isShowing()) fillWeatherPanel();
            });
        });
    }

    /** The line under the clock: icon, temperature, the words for the sky. */
    private void showWeatherLine() {
        if (weatherReport == null) return;
        int sky = Weather.skyOf(weatherReport.code);
        weatherIcon.setImageResource(skyIcon(sky));
        weatherText.setText(getString(R.string.weather_line, weatherReport.temp,
                getString(weatherSky(sky))));
    }

    private void showWeatherPanel() {
        if (weatherPanel != null && weatherPanel.isShowing()) {
            weatherPanel.dismiss();
            return;
        }
        View panel = getLayoutInflater().inflate(R.layout.popup_weather, root, false);
        panel.findViewById(R.id.btnChangeCity).setOnClickListener(v -> {
            weatherPanel.dismiss();
            pickCity();
        });
        panel.findViewById(R.id.btnLocate).setOnClickListener(v -> {
            weatherPanel.dismiss();
            locateCity();
        });
        weatherPanel = new PopupWindow(panel, ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT, true);
        weatherPanel.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        weatherPanel.setOutsideTouchable(true);
        weatherPanel.setElevation(0f);
        dropIn(weatherPanel, panel, weatherLine, Gravity.START);
        fillWeatherPanel();
        // Focus has to move into the panel: left on the line behind it, the D-pad would steer the desk.
        panel.post(() -> panel.findViewById(R.id.btnChangeCity).requestFocus());
    }

    /** Fill the open panel from the last report, or say why there is nothing to show. */
    private void fillWeatherPanel() {
        if (weatherPanel == null || !weatherPanel.isShowing()) return;
        View panel = weatherPanel.getContentView();
        TextView place = panel.findViewById(R.id.place);
        TextView message = panel.findViewById(R.id.message);
        place.setText(weather.placeName());
        if (weatherReport == null) {
            message.setVisibility(View.VISIBLE);
            message.setText(getString(R.string.weather_offline));
            return;
        }
        message.setVisibility(View.GONE);
        int sky = Weather.skyOf(weatherReport.code);
        ((ImageView) panel.findViewById(R.id.icon)).setImageResource(skyIcon(sky));
        ((TextView) panel.findViewById(R.id.temp)).setText(getString(R.string.weather_degrees, weatherReport.temp));
        ((TextView) panel.findViewById(R.id.sky)).setText(getString(weatherSky(sky)));
        ((TextView) panel.findViewById(R.id.feels))
                .setText(getString(R.string.weather_feels, weatherReport.feels));

        TextView air = panel.findViewById(R.id.air);
        if (weatherReport.aqi >= 0) {
            air.setText(getString(R.string.weather_aqi, weatherReport.aqi, getString(aqiLabel(weatherReport.aqi))));
            air.setBackgroundColor(aqiColour(weatherReport.aqi));
            air.setVisibility(View.VISIBLE);
        } else {
            air.setVisibility(View.GONE);
        }

        LinearLayout days = panel.findViewById(R.id.days);
        days.removeAllViews();
        LayoutInflater inflater = getLayoutInflater();
        for (int i = 0; i < weatherReport.days.size() && i < 3; i++) {
            Weather.Day d = weatherReport.days.get(i);
            View row = inflater.inflate(R.layout.item_day, days, false);
            ((TextView) row.findViewById(R.id.dayName)).setText(dayLabel(i));
            ((ImageView) row.findViewById(R.id.dayIcon)).setImageResource(skyIcon(Weather.skyOf(d.code)));
            ((TextView) row.findViewById(R.id.dayTemps))
                    .setText(getString(R.string.weather_high_low, d.max, d.min));
            days.addView(row);
        }
        TextView updated = panel.findViewById(R.id.updated);
        updated.setVisibility(View.VISIBLE);
        updated.setText(getString(R.string.weather_updated,
                android.text.format.DateFormat.getTimeFormat(this).format(new java.util.Date())));
    }

    private String dayLabel(int i) {
        if (i == 0) return getString(R.string.weather_today);
        if (i == 1) return getString(R.string.weather_tomorrow);
        if (i == 2) return getString(R.string.weather_day_after);
        return weatherReport.days.get(i).label;
    }

    // ---- picking a city ---------------------------------------------------------------------------

    /** Type a name with the TV's own keyboard, then pick from what Open-Meteo knows. */
    private void pickCity() {
        View panel = getLayoutInflater().inflate(R.layout.popup_city, root, false);
        EditText input = panel.findViewById(R.id.cityInput);
        LinearLayout results = panel.findViewById(R.id.results);
        TextView message = panel.findViewById(R.id.message);
        input.setText(weather.placeName());
        final PopupWindow popup = new PopupWindow(panel, ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT, true);
        popup.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        popup.setOutsideTouchable(true);
        popup.setElevation(0f);
        popup.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);

        Runnable search = () -> {
            String typed = input.getText().toString();
            if (typed.trim().isEmpty()) return;
            message.setVisibility(View.VISIBLE);
            message.setText(getString(R.string.weather_searching));
            results.removeAllViews();
            executor.execute(() -> {
                List<Weather.Place> found;
                try {
                    found = weather.search(typed);
                } catch (Exception e) {
                    found = null;
                }
                List<Weather.Place> places = found;
                handler.post(() -> {
                    message.setVisibility(View.GONE);
                    if (places == null) {
                        toast(getString(R.string.weather_offline));
                    } else if (places.isEmpty()) {
                        message.setVisibility(View.VISIBLE);
                        message.setText(getString(R.string.weather_pick_none, typed.trim()));
                    } else {
                        for (Weather.Place p : places) {
                            TextView row = (TextView) getLayoutInflater().inflate(R.layout.item_input, results, false);
                            row.setText(p.row());
                            row.setOnClickListener(v -> {
                                weather.place(p.name, p.lat, p.lon);
                                popup.dismiss();
                                refreshWeather();
                                if (weatherPanel != null && weatherPanel.isShowing()) fillWeatherPanel();
                                toast(p.name);
                            });
                            results.addView(row);
                        }
                        results.getChildAt(0).requestFocus();
                    }
                });
            });
        };
        panel.findViewById(R.id.btnSearch).setOnClickListener(v -> search.run());
        input.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEARCH || actionId == EditorInfo.IME_ACTION_GO) {
                search.run();
                return true;
            }
            return false;
        });
        dropIn(popup, panel, weatherLine, Gravity.START);
        input.requestFocus();
    }

    /** One request to ipinfo.io, resolved through the geocoder so the name is the local one. */
    private void locateCity() {
        toast(getString(R.string.weather_locating));
        executor.execute(() -> {
            Weather.Place p;
            try {
                p = weather.locate();
            } catch (Exception e) {
                p = null;
            }
            Weather.Place place = p;
            handler.post(() -> {
                if (place == null) {
                    toast(getString(R.string.weather_locate_failed));
                    return;
                }
                weather.place(place.name, place.lat, place.lon);
                refreshWeather();
                if (weatherPanel != null && weatherPanel.isShowing()) fillWeatherPanel();
                toast(place.name);
            });
        });
    }

    // ---- weather bits -----------------------------------------------------------------------------

    private static int skyIcon(int sky) {
        switch (sky) {
            case 0: return R.drawable.ic_wx_clear;
            case 1: return R.drawable.ic_wx_cloudy;
            case 2: return R.drawable.ic_wx_fog;
            case 3: return R.drawable.ic_wx_drizzle;
            case 4: return R.drawable.ic_wx_rain;
            case 5: return R.drawable.ic_wx_snow;
            case 6: return R.drawable.ic_wx_showers;
            case 7: return R.drawable.ic_wx_snow;
            default: return R.drawable.ic_wx_thunder;
        }
    }

    private static int weatherSky(int sky) {
        switch (sky) {
            case 0: return R.string.wx_clear;
            case 1: return R.string.wx_cloudy;
            case 2: return R.string.wx_fog;
            case 3: return R.string.wx_drizzle;
            case 4: return R.string.wx_rain;
            case 5: return R.string.wx_snow;
            case 6: return R.string.wx_showers;
            case 7: return R.string.wx_snow_showers;
            default: return R.string.wx_thunder;
        }
    }

    /** The US AQI band, for the words under the number. */
    private static int aqiLabel(int aqi) {
        if (aqi <= 50) return R.string.wx_aqi_good;
        if (aqi <= 100) return R.string.wx_aqi_moderate;
        if (aqi <= 150) return R.string.wx_aqi_sensitive;
        if (aqi <= 200) return R.string.wx_aqi_unhealthy;
        if (aqi <= 300) return R.string.wx_aqi_very_unhealthy;
        return R.string.wx_aqi_hazardous;
    }

    /** The same band as a colour, so the pill reads at a glance. */
    private static int aqiColour(int aqi) {
        if (aqi <= 50) return 0xFF2E9E5B;      // green
        if (aqi <= 100) return 0xFFD9A62E;     // yellow
        if (aqi <= 150) return 0xFFE07A2E;     // orange
        if (aqi <= 200) return 0xFFD64545;     // red
        if (aqi <= 300) return 0xFF8E4B9E;     // purple
        return 0xFF8C2F2F;                     // maroon
    }


    // ---- navigation ------------------------------------------------------------------------------

    @Override
    public boolean onTileVerticalKey(int position, int keyCode) {
        if (keyCode==KeyEvent.KEYCODE_DPAD_UP) {
            if(position<layoutColumns)findViewById(R.id.btnWallpaper).requestFocus();
            else focusTile(position-layoutColumns);
        } else {
            int next=position+layoutColumns;
            int lastRow=((adapter.getItemCount()-1)/layoutColumns)*layoutColumns;
            if(next<adapter.getItemCount())focusTile(next);
            else if(position<lastRow)focusTile(adapter.getItemCount()-1);
            else openAppList();
        }
        return true;
    }

    private void focusTile(int position) {
        CardFocus.request(grid, position);
    }

    // ---- top bar ---------------------------------------------------------------------------------

    /** Shows the Wi-Fi network name on the button when we can read it, otherwise the connection type. */
    private void updateWifiLabel() {
        String text = getString(R.string.wifi);
        try {
            ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            Network net = cm != null ? cm.getActiveNetwork() : null;
            NetworkCapabilities caps = net != null ? cm.getNetworkCapabilities(net) : null;
            if (caps == null) {
                text = getString(R.string.offline);
            } else if (caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)) {
                text = getString(R.string.ethernet);
            } else if (caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) {
                WifiManager wm = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
                WifiInfo info = wm != null ? wm.getConnectionInfo() : null;
                String ssid = info != null ? info.getSSID() : null;
                if (ssid != null) {
                    ssid = ssid.replace("\"", "").trim();
                    if (!ssid.isEmpty() && !ssid.contains("unknown") && !ssid.equals("0x")) text = ssid;
                }
            }
        } catch (Exception ignored) {
        }
        btnWifi.setContentDescription(getString(R.string.network) + ": " + text);
        btnWifi.setText(R.string.network);
    }

    private void open(Intent i) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            startActivity(i);
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, R.string.not_available, Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * China-market MIUI TV firmware answers no standard Settings intent at all — both
     * android.settings.SETTINGS and WIFI_SETTINGS resolve to nothing on those sets — so the Settings
     * and Wi-Fi pills dead-end there. Open Xiaomi's own settings app (com.xiaomi.mitv.settings) instead.
     * On firmware that has a standard handler this returns the standard intent unchanged.
     */
    private Intent systemIntent(String standardAction) {
        return systemIntent(this, standardAction);
    }

    /**
     * A system settings screen that is not always there. China-market MIUI TV firmware ignores the
     * standard action, so the Xiaomi settings app is tried as well — see {@code <queries>} in the
     * manifest, without which resolveActivity cannot even see it on Android 11+.
     */
    static Intent systemIntent(android.content.Context ctx, String standardAction) {
        Intent i = new Intent(standardAction);
        if (i.resolveActivity(ctx.getPackageManager()) != null) return i;
        i = new Intent().setComponent(new ComponentName(
                "com.xiaomi.mitv.settings", "com.xiaomi.mitv.settings.entry.MainActivity"));
        if (i.resolveActivity(ctx.getPackageManager()) != null) return i;
        return new Intent(standardAction);   // nothing found: let open() show the can't-open toast
    }

    /** Dropdown menu under the Inputs pill: HDMI ports (with connection state), AV and Live TV. */
    private void showInputs() {
        View anchor = findViewById(R.id.btnInputs);
        View panel = getLayoutInflater().inflate(R.layout.popup_inputs, root, false);
        LinearLayout rows = panel.findViewById(R.id.rows);

        // Compact: as wide as the Inputs pill (a touch wider so "HDMI 1" fits), hanging right below it.
        int width = Math.max(anchor.getWidth(), (int) (150 * density));
        final PopupWindow popup = new PopupWindow(panel, width, ViewGroup.LayoutParams.WRAP_CONTENT, true);
        popup.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));   // needed for Back to dismiss
        popup.setOutsideTouchable(true);
        popup.setAnimationStyle(0);
        popup.setElevation(0f);

        TvInputManager tim = (TvInputManager) getSystemService(TV_INPUT_SERVICE);
        boolean sawNonHdmi = false;
        String tunerId = null;
        if (tim != null) {
            List<TvInputInfo> inputs = new ArrayList<>(tim.getTvInputList());
            // HDMI ports first in port order, then AV and the rest.
            Collections.sort(inputs, (a, b) -> {
                boolean ha = a.getType() == TvInputInfo.TYPE_HDMI, hb = b.getType() == TvInputInfo.TYPE_HDMI;
                if (ha != hb) return ha ? -1 : 1;
                return String.valueOf(a.loadLabel(this)).compareToIgnoreCase(String.valueOf(b.loadLabel(this)));
            });
            // Some TVs (Sony) report every HDMI port as connected whether or not anything is plugged in,
            // so drop the HDMI status then. A TV with every port really in use loses it too.
            int hdmiPorts = 0, hdmiConnected = 0;
            for (TvInputInfo info : inputs) {
                if (!info.isPassthroughInput() || info.getType() != TvInputInfo.TYPE_HDMI) continue;
                hdmiPorts++;
                if (tim.getInputState(info.getId()) == TvInputManager.INPUT_STATE_CONNECTED) hdmiConnected++;
            }
            boolean hdmiStateBogus = hdmiPorts > 1 && hdmiConnected == hdmiPorts;
            for (TvInputInfo info : inputs) {
                if (info.getType() == TvInputInfo.TYPE_TUNER
                        && (info.getServiceInfo().applicationInfo.flags & ApplicationInfo.FLAG_SYSTEM) != 0
                        && (tunerId == null || info.getId().compareTo(tunerId) < 0)) {
                    tunerId = info.getId();
                }
                if (!info.isPassthroughInput()) continue;
                CharSequence l = info.loadLabel(this);
                String label = l == null ? info.getId() : l.toString();
                boolean hdmi = info.getType() == TvInputInfo.TYPE_HDMI;
                if (hdmi && !label.toUpperCase(java.util.Locale.ROOT).contains("HDMI")) label = "HDMI " + label;
                final String id = info.getId();
                int state = hdmi && hdmiStateBogus ? -1 : tim.getInputState(id);
                if (!hdmi && rows.getChildCount() > 0 && !sawNonHdmi) addSeparator(rows);
                if (!hdmi) sawNonHdmi = true;
                addInputRow(rows, popup, hdmi ? R.drawable.ic_input : R.drawable.ic_av, label, state,
                        () -> open(new Intent(Intent.ACTION_VIEW).setDataAndType(
                                TvContract.buildChannelUriForPassthroughInput(id), "vnd.android.cursor.item/channel")));
            }
        }
        Intent liveTv = liveTvPkg.isEmpty() ? null : getPackageManager().getLeanbackLaunchIntentForPackage(liveTvPkg);
        if (liveTv != null && tunerId != null) {
            liveTv = new Intent(Intent.ACTION_VIEW)
                    .setDataAndType(TvContract.buildChannelUriForPassthroughInput(tunerId), "vnd.android.cursor.item/channel")
                    .setPackage(liveTvPkg);
        }
        // A vendor panel configured in config.xml, with no Live TV row to sit beside it: the panel is
        // the whole menu. Sets like the BYINTEK U4 report HDMI ports they do not have, and their own
        // picker is the honest one.
        if (!panelConfigured() && liveTv == null) {
            if (rows.getChildCount() == 0) {
                // Nothing to list either (Xiaomi and some Chinese ROMs do not report their ports).
                Intent own = sourcePanelIntent();
                if (own == null) {
                    Toast.makeText(this, R.string.no_inputs, Toast.LENGTH_SHORT).show();
                    return;
                }
                final Intent target = own;
                addInputRow(rows, popup, R.drawable.ic_av, getString(R.string.input_source_settings), -1,
                        () -> openSourcePanel());
            }
        } else if (panelConfigured() && liveTv == null) {
            openSourcePanel();
            return;
        }
        if (liveTv != null) {
            if (rows.getChildCount() > 0) addSeparator(rows);
            final Intent liveTvIntent = liveTv;
            addInputRow(rows, popup, R.drawable.ic_livetv, getString(R.string.live_tv), -1, () -> open(liveTvIntent));
        }

        // Fit the widest row: TVs that report a status on every port (Sony) would otherwise squeeze the names out.
        panel.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED);
        popup.setWidth(Math.max(width, panel.getMeasuredWidth()));

        dropIn(popup, panel, anchor, Gravity.START);
        rows.getChildAt(0).requestFocus();
    }

    /**
     * A glass dropdown built the way the Inputs menu is: as wide as its widest row but never most of
     * the screen, and no taller than the room under the button, so a long list scrolls inside the
     * panel instead of running off the bottom of the TV.
     */
    private PopupWindow settingsPanel(View panel, View anchor, int minWidthDp) {
        panel.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED);
        int width = Math.max(Math.max(anchor.getWidth(), (int) (minWidthDp * density)),
                panel.getMeasuredWidth());
        width = Math.min(width, (int) (getResources().getDisplayMetrics().widthPixels * 0.72f));
        int[] at = new int[2];
        anchor.getLocationInWindow(at);
        int room = root.getHeight() - (at[1] + anchor.getHeight()) - (int) (34 * density);
        int height = Math.min(panel.getMeasuredHeight(), Math.max(room, (int) (120 * density)));
        PopupWindow popup = new PopupWindow(panel, width, height, true);
        popup.setElevation(0f);
        return popup;
    }

    /** Drop in: fade and unfold from the top edge, hanging under the anchor. */
    private void dropIn(PopupWindow popup, View panel, View anchor, int gravity) {
        if (reducedMotion) {
            // Weak boxes: the unfold costs frames the user notices as lag, so just put it on screen.
            popup.showAsDropDown(anchor, 0, (int) (10 * density), gravity);
            return;
        }
        panel.setAlpha(0f);
        popup.showAsDropDown(anchor, 0, (int) (10 * density), gravity);
        panel.animate().alpha(1f).setDuration(120)
                .setInterpolator(new android.view.animation.DecelerateInterpolator(1.6f)).start();
    }

    private void addSeparator(LinearLayout rows) {
        View line = new View(this);
        line.setBackgroundColor(0x1FFFFFFF);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (int) density);
        int m = (int) (6 * density), h = (int) (12 * density);
        lp.setMargins(h, m, h, m);
        rows.addView(line, lp);
    }

    private void addInputRow(LinearLayout rows, PopupWindow popup, int iconRes, String title, int state, Runnable action) {
        View row = getLayoutInflater().inflate(R.layout.item_input, rows, false);
        ((ImageView) row.findViewById(R.id.icon)).setImageResource(iconRes);
        ((TextView) row.findViewById(R.id.title)).setText(title);
        TextView status = row.findViewById(R.id.status);
        View dot = row.findViewById(R.id.dot);
        // This TV reports "standby" for every port whether or not something is plugged in, so only
        // definite states are shown.
        if (state == TvInputManager.INPUT_STATE_CONNECTED) {
            status.setText(R.string.connected);
            dot.setVisibility(View.VISIBLE);
        } else if (state == TvInputManager.INPUT_STATE_DISCONNECTED) {
            status.setText(R.string.not_connected);
            dot.setVisibility(View.GONE);
        } else {
            status.setVisibility(View.GONE);
            dot.setVisibility(View.GONE);
        }
        row.setOnClickListener(v -> {
            popup.dismiss();
            action.run();
        });
        rows.addView(row);
    }
}
